import 'package:flutter/material.dart';

void main() => runApp(
  MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.indigoAccent,
        child: const Icon(Icons.navigation),
        onPressed: (){
        },
      ),
      appBar: AppBar(
        backgroundColor: Colors.indigoAccent,
        title: const Center(
          child: Text('Ma premiere Application',
              style:TextStyle(
                  fontFamily: 'Pacifico',
                  fontSize: 23.0,
                  fontWeight: FontWeight.bold
              )
          ),
        ),
      ),
      body: const Center(
        child: Image(
           image: AssetImage('images/de.jpg'),
          //   image: NetworkImage('https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/UtrechtIconoclasm.jpg/800px-UtrechtIconoclasm.jpg')
        ),
      ),
    ),
  ),
);
