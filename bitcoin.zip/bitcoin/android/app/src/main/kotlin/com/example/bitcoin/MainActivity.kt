package com.example.bitcoin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
