import 'package:climaipnet/screens/model.dart';
import 'package:flutter/material.dart';
import '../services/weather.dart';
class LoadingScreen extends StatefulWidget {
  const LoadingScreen({super.key});

  @override
  _LoadingScreenState createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen> {
  WeatherModel donnees = WeatherModel();
  Weather da = Weather();
  Future<void> getData() async{
      da = await donnees.getCurrentWeather("cotonou");
  }
  // @override
  // void initState(){
  //   super.initState();
  //   donnees.getCurrentWeather("lomé");
  //   Weather da = Weather();
  //   print(da.description);
  //
  // }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body:FutureBuilder(
        future: getData(),
        builder: (context , snapshot){
          if(snapshot.connectionState == ConnectionState.done){
            return Column(
              children: [
                Container(
                  height: size.height * 0.64,
                  width: size.width,
                  padding: const EdgeInsets.only(top: 20)  ,
                  margin: const EdgeInsets.only(top:23, right: 10, left: 10),
                  decoration: BoxDecoration(
                      borderRadius:BorderRadius.circular(40),
                      gradient: const LinearGradient(
                        colors: [
                          Colors.white38,
                          Colors.indigo,
                        ],
                        begin: Alignment.bottomCenter,
                        end:  Alignment.topCenter,
                        stops: [0.2,0.85],
                      )
                  ),
                  child: Column(
                    children:  [
                      Text(

                        '${da.cityName}',
                        style: TextStyle(
                            color: Colors.white.withOpacity(0.9) ,
                            fontSize: 35,
                            fontFamily: 'SpartanMB') ,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      // Image.asset('images/soleil.png',
                      //   width: size.width*0.4,
                      // ),
                      Image.network('https:${da.icon}',
                        width: size.width * 0.2,
                      fit:BoxFit.fill),
                      const SizedBox(
                        height: 10,
                      ),
                       Text(
                        '${da.condition} ',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'SpartanMB') ,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                        Text(
                        '${da.temp}°C ',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 35,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'SpartanMB') ,
                      ),
                      const SizedBox(
                        height: 5,
                      ),
                      Row(
                        children: [
                          Expanded(child: Column(
                            children: [
                              // Image.asset('images/storm.png',
                              //     width: size.width * 0.14),
                              Text(
                                '${da.wind} km/h',
                                style:  const TextStyle(color: Colors.white,
                                    fontFamily: 'SpartanMB',
                                    fontSize: 15, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Text(
                                'Vent',
                                style: TextStyle(color: Colors.white.withOpacity(0.6),
                                    fontFamily: 'SpartanMB',
                                    fontSize: 11, fontWeight: FontWeight.bold
                                ),
                              ),
                            ],
                          ),),
                          Expanded(child: Column(
                            children: [
                              // Image.asset('images/pluie.png',
                              //     width: size.width * 0.14),
                               Text(
                                '${da.humidity}g/m3',
                                style: const TextStyle(color: Colors.white,
                                    fontFamily: 'SpartanMB',
                                    fontSize: 15, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Text(
                                'Humidite',
                                style: TextStyle(color: Colors.white.withOpacity(0.6),
                                    fontFamily: 'SpartanMB',
                                    fontSize: 11, fontWeight: FontWeight.bold
                                ),
                              ),
                            ],
                          ),),
                          Expanded(child: Column(
                            children: [
                              // Image.asset('images/voile.png',
                              //     width: size.width * 0.14),
                               Text(
                                '${da.wind_dir}',
                                style: const TextStyle(color: Colors.white,
                                    fontFamily: 'SpartanMB',
                                    fontSize: 15, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              Text(
                                'Direction Vent ',
                                style: TextStyle(color: Colors.white.withOpacity(0.6),
                                    fontFamily: 'SpartanMB',
                                    fontSize: 11, fontWeight: FontWeight.bold
                                ),
                              ),
                            ],
                          ),
                          ),
                        ],
                      ),
                    ],
                  ),

                ),
                 const SizedBox( height: 20,),
                 Text( ' Informations supplementaires ' ,style: TextStyle(
                    color: Colors.white.withOpacity(0.5),
                    fontFamily: 'SpartanMB', fontSize: 12,
                   decoration: TextDecoration.underline,
                )),
                const SizedBox( height: 10,),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        children:  [
                          Text('Precipitation', style:
                          TextStyle(
                              color: Colors.white.withOpacity(0.5),
                              fontFamily: 'SpartanMB', fontSize: 12),
                          ),
                          const SizedBox(height: 5,),
                           Text('${da.pricipe} mm', style:
                           const TextStyle(
                              color: Colors.white, fontFamily: 'SpartanMB',
                              fontSize: 17),
                          ),
                          const SizedBox( height: 15 ,),
                          Text('Pression', style:
                          TextStyle(
                              color: Colors.white.withOpacity(0.5),
                              fontFamily: 'SpartanMB', fontSize: 12),
                          ),
                          const SizedBox(height: 5,),
                           Text('${da.pressure}hpa', style:
                           const TextStyle(
                              color: Colors.white, fontFamily: 'SpartanMB',
                              fontSize: 17),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        children:  [
                          Text(' UV', style:
                          TextStyle(
                              color: Colors.white.withOpacity(0.5),
                              fontFamily: 'SpartanMB', fontSize: 12),
                          ),
                          const SizedBox(height: 5,),
                           Text('${da.uv} ', style:
                           const TextStyle(
                              color: Colors.white, fontFamily: 'SpartanMB',
                              fontSize: 17),
                          ),
                          const SizedBox( height: 15 ,),
                          Text('Rafale', style:
                          TextStyle(
                              color: Colors.white.withOpacity(0.5),
                              fontFamily: 'SpartanMB', fontSize: 12),
                          ),
                          const SizedBox(height: 5,),
                           Text('${da.gust}Kp/h', style:
                           const TextStyle(
                              color: Colors.white, fontFamily: 'SpartanMB',
                              fontSize: 17),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Column(
                        children:  [
                          Text('Vent', style:
                          TextStyle(
                              color: Colors.white.withOpacity(0.5),
                              fontFamily: 'SpartanMB', fontSize: 12),
                          ),
                          const SizedBox(height: 5,),
                           Text('${da.wind}  ', style:
                           const TextStyle(
                              color: Colors.white, fontFamily: 'SpartanMB',
                              fontSize: 17),
                          ),
                          const SizedBox( height: 15 ,),
                          Text('Mise A Jour ', style:
                          TextStyle(
                              color: Colors.white.withOpacity(0.5),
                              fontFamily: 'SpartanMB', fontSize: 12),
                          ),
                          const SizedBox(height: 5,),
                           Text('${da.last_update}', style:
                           const TextStyle(
                              color: Colors.green, fontFamily: 'SpartanMB',
                              fontSize: 12),
                          ),
                        ],
                      )
                    ),
                  ],
                ),
              ],
            );
          }
          return Container();

        },
      ),
    );
  }
}
