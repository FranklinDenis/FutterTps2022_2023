class Weather {
  String? cityName ;
  String? icon;
  String? condition ;
  double? temp;
  double? wind;
  int? humidity ;
  String? wind_dir;
  double? gust;
  double? uv;
  double? pressure;
  double? pricipe;
  String? last_update;


  Weather ({
     this.cityName,
     this.temp,
     this.wind,
     this.icon,
     this.humidity,
     this.condition,
     this.wind_dir,
     this.gust,
     this.pressure,
     this.uv,
     this.pricipe,
     this.last_update,

  });
  Weather.fromJson(Map<String, dynamic> json ){
    cityName =json['location']['name'];
    temp = json['current']['temp_c'];
    wind = json['current']['wind_kph'];
    wind_dir = json['current']['wind_dir'];
    humidity = json['current']['humidity'];
    uv = json['current']['uv'];
    condition = json['current']['condition']['text'];
    pricipe =  json['current']['precip_mm'];
    gust =  json['current']['gust_kph'];
    last_update  =  json['current']['last_updated'];
    pressure= json['current']['pressure_mb'];
    icon = json['current']['condition']['icon'];

  }
}