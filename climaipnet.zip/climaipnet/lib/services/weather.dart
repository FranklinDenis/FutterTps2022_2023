
import 'dart:async';
import 'dart:convert';

import 'package:climaipnet/screens/model.dart';
import 'package:http/http.dart' as http;
import 'location.dart';
import 'networking.dart';
const apiKey="c623c339cdf446c9934115955221612";
const openWeatherUrl ="http://api.weatherapi.com/v1/current.json";

class WeatherModel {


  Future<Weather>getCurrentWeather(String? cityName) async{
    var endpoint = Uri.parse(
        "$openWeatherUrl?key=$apiKey&q=$cityName&aqi=no");
    var response = await http.get(endpoint);
    var body = jsonDecode(response.body);
    print(Weather.fromJson(body));
    return Weather.fromJson(body);

  }

  // //Lancer une requete vers l'API pour recuperer City
  // Future<dynamic> getCityWeather(String cityName) async {
  //   String url = "$openWeatherUrl?q=$cityName&appid=$apiKey&units = metric";
  //   NetWorkHelper netWorkHelper=NetWorkHelper(url: url);
  //   var weatherData = await netWorkHelper.getData();
  //   print(weatherData);
  //   return weatherData;
  // }
  //
  //
  // //Lancer une requete vers l'API pour recuperer position
  // Future<dynamic> getLocationWeather(var latitude , var longitude ) async {
  //   Location l = Location();
  //   await l.getCurrentLocation();
  //
  //   String url = "$openWeatherUrl?q=lat=${l.latitude}&lon=${l.longitude}&appid=$apiKey";
  //   NetWorkHelper netWorkHelper=NetWorkHelper(url: url);
  //   var weatherData = await netWorkHelper.getData();
  //
  //   return weatherData;
  // }
  //
  //
  // String getWeatherIcon(int condition) {
  //   if (condition < 300) {
  //     return '🌩';
  //   } else if (condition < 400) {
  //     return '🌧';
  //   } else if (condition < 600) {
  //     return '☔️';
  //   } else if (condition < 700) {
  //     return '☃️';
  //   } else if (condition < 800) {
  //     return '🌫';
  //   } else if (condition == 800) {
  //     return '☀️';
  //   } else if (condition <= 804) {
  //     return '☁️';
  //   } else {
  //     return '🤷‍';
  //   }
  // }
  //
  // String getMessage(int temp) {
  //   if (temp > 25) {
  //     return 'It\'s 🍦 time';
  //   } else if (temp > 20) {
  //     return 'Time for shorts and 👕';
  //   } else if (temp < 10) {
  //     return 'You\'ll need 🧣 and 🧤';
  //   } else {
  //     return 'Bring a 🧥 just in case';
  //   }
  // }
}
