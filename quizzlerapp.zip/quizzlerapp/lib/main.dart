import 'package:flutter/material.dart';

void main() => runApp(quizzler());

class quizzler extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.grey.shade900,
        body: SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.0),
            child: QuizPage(),
          ),
        ),
      ),
    );
  }
}

class QuizPage extends StatefulWidget {
  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  List<String> questions=[
    'Le togo a eu son indépendance le 05 juillet 1884.',
    "L'actuel président du Togo est Faure GNASSINGBE.",
    "Etudier n'est pas facile.",

  ];

  List<bool>reponse=[false, true, true];

  List<Icon>score=[];
  /*Icon(
      Icons.check, color: Colors.green,
    ),
    Icon(
      Icons.close, color: Colors.red,
    )*/


  int numQuestion=0;

  void incrementation( bool reponse_user){
    if(questions.length > score.length) {

      if (reponse_user==reponse[numQuestion]){
        score.add(const Icon(Icons.check_circle_rounded,color: Colors.green),
        );
      }
      else {
        score.add(const Icon(Icons.close_rounded, color: Colors.red),
        );
      }

      print(numQuestion);

      setState(() {
        if(questions.length> score.length){
          numQuestion++;
        }
      });

    }


  }
  @override
  Widget build(BuildContext context) {

    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Expanded(
          flex: 5,
          child: Padding(
            padding: EdgeInsets.all(10.0),
            child: Center(
              child: Text(
                questions[numQuestion],
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 25.0,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.all(15.0),
            child: TextButton(
              style: TextButton.styleFrom(
                  backgroundColor: Colors.green
              ),
              child: const Text(
                'Vrai',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.0,
                ),
              ),
              onPressed: () {
                incrementation(true);
                //The user picked true.
              },
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.all(15.0),
            child: TextButton(
              style: TextButton.styleFrom(
                  backgroundColor: Colors.red
              ),
              child: const Text(
                'Faux',
                style: TextStyle(
                  fontSize: 20.0,
                  color: Colors.white,
                ),
              ),
              onPressed: () {
                incrementation(false);
                //The user picked false.
              },
            ),
          ),
        ),
        //TODO: Add a Row here as your score keeper
        Row(
            children:score
        )
      ],
    );
  }
}

/*
question1: 'Le togo a eu son indépendance le 05 juillet 1884.', faux,
question2: "L'actuel président du Togo est Faure GNASSINGBE.", vrai,
question3: "Etudier n'est pas facile.", vrai,
*/