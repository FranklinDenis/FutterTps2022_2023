package com.example.tp3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
