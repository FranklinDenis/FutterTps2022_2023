package com.example.tp4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
