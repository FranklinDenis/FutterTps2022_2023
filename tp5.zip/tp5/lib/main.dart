import 'package:flutter/material.dart';
import 'dart:math';
void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // This widget is the root of your application.
  int numball=1;
  void charger_image(){
    setState((){
      numball = Random().nextInt(5)+1;
      print('image cliquee');

    });
  }
  @override
  Widget build(BuildContext context) {
    return  MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: const Color(0XFF3158ab),
          title: const Text('ASK ME ANYTHING',
              style: TextStyle(
                  fontSize: 20,
                  fontFamily: 'Nunito'
              )),
        ),
        body: Center(
          child: TextButton(
              onPressed: (){
                charger_image();
              },
              child:  Image(
                image: AssetImage('images/ball$numball.png'),
              )
          ),
        ),
      ),
    );
  }
}
