package com.example.tp6

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
