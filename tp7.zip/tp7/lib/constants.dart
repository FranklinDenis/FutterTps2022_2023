import 'package:flutter/material.dart';

const kMyTextStyle=TextStyle(
fontSize: 40.0
);